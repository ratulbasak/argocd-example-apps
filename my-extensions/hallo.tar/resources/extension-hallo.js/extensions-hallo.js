((window) => {
  const { useEffect, useState } = React;

  const HttpCallComponent = (props) => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const backendServiceUrl = '/extensions/hallo/api/todos';

    useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await fetch(backendServiceUrl, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
            },
          });

          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }

          const result = await response.json();
          console.log("data: ", result);
          setData(result);
        } catch (err) {
          setError(err.message);
        } finally {
          setLoading(false);
        }
      };

      fetchData();
    }, []);

    if (loading) {
      return <div>Loading...</div>;
    }

    if (error) {
      return <div>Error: {error}</div>;
    }

    return (
      <div>
        <h3>Data from Backend Service:</h3>
        <pre>{JSON.stringify(data, null, 2)}</pre>
      </div>
    );
  };

  window.extensionsAPI.registerResourceExtension(
    HttpCallComponent,
    "apps", // API group for Deployments, StatefulSets, etc.
    "Deployment", // Kind for Deployments
    "TODO" // Tab title
  );

  window.extensionsAPI.registerResourceExtension(
    HttpCallComponent,
    "apps", // API group for StatefulSets
    "StatefulSet", // Kind for StatefulSets
    "TODO" // Tab title
  );

  window.extensionsAPI.registerResourceExtension(
    HttpCallComponent,
    "apps", // API group for DaemonSets
    "DaemonSet", // Kind for DaemonSets
    "TODO" // Tab title
  );
})(window);