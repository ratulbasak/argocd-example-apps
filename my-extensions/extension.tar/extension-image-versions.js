// extension-image-versions.js
((window) => {
  const component = (props) => {
    const { resource } = props;
    const images = resource.spec.template.spec.containers.map(container => container.image);
    return React.createElement(
      "div",
      { style: { padding: "10px" } },
      `Deployed Images: ${images.join(", ")}`
    );
  };

  window.extensionsAPI.registerResourceExtension(
    component,
    "argoproj.io", // Match all groups
    "Application", // Match all kinds
    "Deployed Image Versions"
  );
})(window);